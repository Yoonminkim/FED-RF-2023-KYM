
const liData = {

    "banner1" : {
        "TEXT" : ["THIS IS FOR YOU", "texttext"],
        "IMAGE" : "../99. IMAGE/01.png"
    },
    "banner2" : {
        "TEXT" : ["THIS IS FOR YOU", "texttext"],
        "IMAGE" : "../99. IMAGE/02.png"
    },
    "banner3" : {
        "TEXT" : ["THIS IS FOR YOU", "texttext"],
        "IMAGE" : "../99. IMAGE/03.png"
    },
    "banner4" : {
        "TEXT" : ["THIS IS FOR YOU", "texttext"],
        "IMAGE" : "../99. IMAGE/04.png"
    },
    "banner5" : {
        "TEXT" : ["THIS IS FOR YOU", "texttext"],
        "IMAGE" : "../99. IMAGE/01.png"
    },
    "banner6" : {
        "TEXT" : ["THIS IS FOR YOU", "texttext"],
        "IMAGE" : "../99. IMAGE/02.png"
    }

}

export default liData;